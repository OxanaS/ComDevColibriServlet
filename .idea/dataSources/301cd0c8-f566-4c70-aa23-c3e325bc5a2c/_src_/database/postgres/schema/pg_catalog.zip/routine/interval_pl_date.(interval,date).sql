CREATE FUNCTION interval_pl_date (interval, date) RETURNS timestamp without time zone
	LANGUAGE sql
AS $$
select $2 + $1
$$
